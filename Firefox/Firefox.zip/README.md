# redmine-tte-extension

Redmine Today’s Time Entries Firefox Extension

Download: https://addons.mozilla.org/tr/firefox/addon/redmine-today-s-time-entries/

About extension (Turkish): http://semihcelikol.com/firefox-eklenti-redmine-todays-time-entries/

semihcelikol.com